syms x
function=x^3

end