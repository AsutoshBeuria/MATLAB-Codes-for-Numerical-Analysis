%in this example I am writing  a programm to calculate the volume of a
%sphere
%volume=v
%R=Radius
R=5;
v=(4/3)*pi*r^3
