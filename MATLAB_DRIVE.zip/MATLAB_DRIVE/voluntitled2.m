% In this example I am writting a program to calculate the volume of a
% sphere v=(4/3)*pi*r^3

%volume=v
%r=radius
clear all
clc

r=5;
volume=(4/3)*pi*r^3