% calculate the area of a circle symbollically

syms r
area
r=sym(3/4)
area=pi*r^2
double(area)
area
pretty(area)
syms x y z
(x^2-z^3+y)/(-y^2+x^3+3)
pretty(ans)
factorial(3)
sqrt(4)
9^(1/2)
81^(1/2)
nthroot(27,3)
nthroot(81,4)
x=9;
b=sqrt(x)+45
sym(sqrt(8933))
pretty(ans)
sin(30)
tan(90)
