function output=ploy(x)
    output=1234*x^2+531*x-123
    
end