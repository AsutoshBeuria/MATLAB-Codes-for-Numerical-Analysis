A=[1 2 3;3 3 4; 2 3 3];
b=[1 ;1 ;  2];
x = linsolve(A,b)