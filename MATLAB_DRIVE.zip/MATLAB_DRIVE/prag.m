if x>0
    y=log(x)
else
    disp('The input of log can't be negative:')
    
end