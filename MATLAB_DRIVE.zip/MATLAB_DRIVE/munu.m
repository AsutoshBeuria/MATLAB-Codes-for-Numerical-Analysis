if x>0
    y = log(x)
else
    disp('the input of log cant be negative :')
end
