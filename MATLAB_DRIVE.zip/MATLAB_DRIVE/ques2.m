f = @myfun;
a = 0;
b = 2;
delta = 1e-05;
sol = bisect(f,a,b,delta) 
