function rho_npcm = myrho_npcm(phi,pho_pcm)
    % function calculates the value of rho_npcm
    x = rho_np*phi + rho_pcm*(1-phi);
    rho_np = 3600;
end